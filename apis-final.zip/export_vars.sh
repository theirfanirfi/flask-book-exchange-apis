export FLASK_APP=application.py
export FLASK_DEBUG=1